from django.shortcuts import render


def home(request):
    context = {
        "portal_name": "Campus Student Portal",
        "welcome_message": "Welcome to the Student Portal — your hub for department updates, schedules, and study resources.",
        "features": [
            "Department announcements and important notices",
            "Class and laboratory schedules",
            "Course materials, guides, and student resources",
        ],
    }
    return render(request, "portal/home.html", context)


def about(request):
    context = {
        "portal_name": "Campus Student Portal",
        "purpose": "Designed to help students easily access announcements, schedules, and department resources in one place.",
        "intended_users": "Students, student leaders, and department instructors.",
        "accessibility_feature": "High-contrast colors, descriptive image alt text, and visible keyboard focus outlines (:focus-visible) on navigation links.",
    }
    return render(request, "portal/about.html", context)